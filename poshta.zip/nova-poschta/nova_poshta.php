<?php
/**
Plugin Name: Nova Poshta
Version: 1.0.0
Author: web24
Description: Adds multilingual capability to WordPress
Text Domain: Nova Poshta
Domain Path: /languages
 */


include "include/nova_poshta_checkout.php";
// include "C:\OSPanel\domains\wordpress\wp-content\plugins\woocommerce\woocommerce.php";

add_action( 'plugins_loaded', 'true_load_plugin_nova_poshta' );
 
function true_load_plugin_nova_poshta() {
	load_plugin_textdomain( 'nova-poshta', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
function nova_poshta_shipping_quote_init() {
    if ( ! class_exists( 'Nova_Poshta' ) ) {

        class Nova_Poshta extends WC_Shipping_Method {
			 public function __construct() {
                    $this->id                 = 'nova_poshta'; 
                    $this->method_title       = __( 'Nova poshta', 'nova-pohta' );  
                    $this->method_description = __( 'Setting shipping Nova Poshta', 'nova-pohta' ); 

                    
				 // Availability & Countries
                    $this->availability = 'including';
                    $this->countries = array(
                        'UA' // Доставка тільки по Україні
                        );
                        

                    $this->init();
 
                    $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
                    $this->title = isset( $this->settings['Titlen'] ) ? $this->settings['Titlen'] : __( 'Nova Poshta Shipping', 'nova-pohta' );
                }

			 function init() {
                    // Load the settings API
                    $this->init_form_fields(); 
                    $this->init_settings(); 
 
                    // Save settings in admin if you have any defined
                    add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
                }
			 function init_form_fields() { 
 
                    $this->form_fields = array(
 
                     	'enabled' => array(
                          	'title' => __( 'Enable', 'nova-pohta' ),
                          	'type' => 'checkbox',
                          	'description' => __( 'Enable this shipping.', 'nova-pohta' ),
                          	'default' => 'yes'
                          ),
 						'Titlen' => array(
    						'title'    => __( 'Title', 'nova-poshta' ),
    						'desc'    => '<br>'.__( 'This controls the title which the user sees during checkout', 'nova-poshta' ),
    						'id'      => 'title_nova_poshta',
    						'type'    => 'text'
  						),
						'your_key_api' => array(
    						'title'    => __( 'Your key API', 'nova-poshta' ),
    						'desc'    => '<br>'.__( 'Set key API 2.0', 'nova-poshta' ).'(<a href="#">'.__( 'new/info', 'nova-poshta' ).'</a>)',
				
    						'id'      => 'key_API_nova_poshta',
    						'type'    => 'text'
  						),
						'calculete_shipping' => array(
							'title'     => __( 'On calculete shipping', 'nova-poshta' ),
							'desc' => __('On calculete shipping.', 'nova-poshta'),
							'type'      => 'checkbox',
							'id'        => 'calculete_shipping_nova_poshta'
						),
						'default_weight' => array(
							'title'     => __( 'Default weight, g', 'nova-poshta' ),
							'desc' => __('Weight', 'nova-poshta'),
							'desc_tip' => true,
							'type'      => 'number',
							'id'        => 'default_weight_nova_poshta'
						),
						'package_weight' => array(
							'title'     => __( 'Package weight, g', 'nova-poshta' ),
							'desc' => __('Weight', 'nova-poshta'),
							'desc_tip' => true,
							'type'      => 'number',
							'id'        => 'package_weight_nova_poshta'
						),
						'address_of_the_sender' => array(
							'title'     => __( 'Address of the sender', 'nova-poshta' ),
							'type'    => 'select',
    						'options' => array(
      							"Volochys'k" => __( "Volochys'k", 'nova-poshta' ),
      							'Kyiv' => __( 'Kyiv', 'nova-poshta' ),
      							'Lviv'=> __( 'Lviv', 'nova-poshta' ), 
      							'Lviv'=> __( 'Lviv', 'nova-poshta' ),
      							'Odesa'  => __( 'Odesa', 'nova-poshta' ),
      							'Harkiv' => __( 'Harkiv', 'nova-poshta' )
					
						),
			
							'id'=> 'address_of_the_sender_nova_poshta'),
						'address_of_the_sender_the_parcel' => array(
							'title'     => __( 'The sender (seller) makes the parcel', 'nova-poshta' ),
							'type'    => 'select',
    						'options' => array(
      							'Warehouse'=> __( 'From stock', 'nova-poshta' ),
      							'Doors'=> __( 'Courier', 'nova-poshta' ),
      								
						),
			
							'id'=> 'address_of_the_sender_the_parcel_nova_poshta'),
						'address_of_the_sender_the_parcel_paid' => array(
							'title'     => __( 'Delivery is paid', 'nova-poshta' ),
							'type'    => 'select',
    						'options' => array(
      							'Shopper' => __( 'Shopper', 'nova-poshta' ),
      							'Seller'  => __( 'Seller', 'nova-poshta' )		
						),
							'css'     => 'width: 110px;',
							'id'        => 'address_of_the_sender_the_parcel_paid_nova_poshta'),
						'The_display_language_of_the_cities' => array(
							'title'     => __( 'The display language of the cities', 'nova-poshta' ),
							'type'    => 'select',
    						'options' => array(
    							'ru'        => __( 'Russian', 'nova-poshta' ),
      							'ua'  => __( 'Ukrainian', 'nova-poshta' )		
						),
							'css'     => 'width: 110px;',
							'id'        => 'The_display_language_of_the_cities_nova_poshta'),
						'currency' => array(
							'title'     => __( 'Сourse', 'nova-poshta' ),
							'type'    => 'select',
    						'options' => array(
      							'auto' => __( 'Auto', 'nova-poshta' ),
      							'manual'  => __( 'Manual', 'nova-poshta' )		
						),
							'css'     => 'width: 110px;',
						'id'=> 'currency_nova_poshta',
						),
						'currency_number_usd' => array(
							'title'     => __( 'Сourse for the default, usd', 'nova-poshta' ),
							'desc' => __('Weight', 'nova-poshta'),
							'desc_tip' => true,
							'type'      => 'number',
							'id'        => 'currency_number_usd_nova_poshta'
						),
						'currency_number_eur' => array(
							'title'     => __( 'Сourse for the default, eur', 'nova-poshta' ),
							'desc' => __('Weight', 'nova-poshta'),
							'desc_tip' => true,
							'type'      => 'number',
							'id'        => 'currency_number_eur_nova_poshta'
						),
						'currency_number_rur' => array(
							'title'     => __( 'Сourse for the default, rur', 'nova-poshta' ),
							'desc' => __('Weight', 'nova-poshta'),
							'desc_tip' => true,
							'type'      => 'number',
							'id'        => 'currency_number_rur_nova_poshta'
						),
						
						
	
 
                     );
				 
				 

                }
 public function calculate_shipping( $package = array()) {
                    
                    $weight = 0;
                    $cost = 0;
                    $country = $package["destination"]["address_city"];
 //echo $package["destination"]["state"];
 
	   @session_start();
if($_SESSION['shippingCost']){
	$cost=$_SESSION['shippingCost'];
	}
	 else {
		$cost=0;
//		 	 	 echo "cost";

	 }
	 
 
                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => $cost
                    );
 
                    $this->add_rate( $rate );

                }
		}

	}

}
 
	 function shipingonline_calculator() {
	
 @session_start();
          if($_REQUEST['vidilenya']!='free'){
	    
		 $_SESSION['shippingCost']=$_REQUEST['vidilenya'];
			      echo "Вдало";

 }
		 else{
			 $_SESSION['shippingCost']=0;
			 echo "Пасивно";
		 }
		

   }
			 		
add_action('wp_ajax_novaposhta_shipingonline', 'shipingonline_calculator');
add_action('wp_ajax_nopriv_novaposhta_shipingonline', 'shipingonline_calculator');


	 function adminData() {
$dani;
		 
		 
		   $packages = WC()->shipping->get_packages();
 
        $chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
         
        if( is_array( $chosen_methods ) && in_array( 'nova_poshta', $chosen_methods ) ) {
             
            foreach ( $packages as $i => $package ) {
 
                if ( $chosen_methods[ $i ] != "nova_poshta" ) {
                             
                    continue;
                             
                }
 
            
				
			}
			
        
		}
		 $Nova_Poshta = new Nova_Poshta();
		 
		 		
		 $dani['key_api'] =  $Nova_Poshta->settings['your_key_api'];;
		 $dani['default_weight'] =  ($Nova_Poshta->settings['default_weight']/1000)+($Nova_Poshta->settings['package_weight']/1000);
		 $dani['calculete_shipping'] =  $Nova_Poshta->settings['calculete_shipping'];
		 $dani['address_of_the_sender'] =  $Nova_Poshta->settings['address_of_the_sender'];
		 $dani['language_of_the_cities'] =  $Nova_Poshta->settings['The_display_language_of_the_cities'];
		 $dani['address_of_the_sender_the_parcel_paid'] =  $Nova_Poshta->settings['address_of_the_sender_the_parcel_paid'];
		 $dani['address_of_the_sender_the_parcel'] =  $Nova_Poshta->settings['address_of_the_sender_the_parcel'];
		 $dani['currencies']= get_woocommerce_currency(); //> RUB
		 $dani['currency']=$Nova_Poshta->settings['currency'];
		 $dani['currency_number_usd']=$Nova_Poshta->settings['currency_number_usd'];
		 $dani['currency_number_eur']=$Nova_Poshta->settings['currency_number_eur'];
		 $dani['currency_number_rur']=$Nova_Poshta->settings['currency_number_rur'];

		 echo json_encode($dani);
		 
		 
 }
			 		
add_action('wp_ajax_novaposhta_admin_Data', 'adminData');
add_action('wp_ajax_nopriv_novaposhta_admin_Data', 'adminData');




    add_action( 'woocommerce_shipping_init', 'nova_poshta_shipping_quote_init' );
function add_nova_poshta_shipping_method( $methods ) {
        $methods[] = 'Nova_Poshta';
        return $methods;
    }
 
    add_filter( 'woocommerce_shipping_methods', 'add_nova_poshta_shipping_method' );



function my_custom_checkout_field( $checkout ) {//сss js
	wp_register_style('nova_poshta', plugins_url('/css/nova_poshta_style.css',__FILE__ ));
   wp_enqueue_style('nova_poshta');
        wp_enqueue_script( 'ajax-script',
        plugins_url( '/js/page_nova_poshta.js', __FILE__ ),
        array( 'jquery' )    
						 );}
add_action( 'woocommerce_after_order_notes', 'my_custom_checkout_field' );


