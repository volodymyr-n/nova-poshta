<?php

function custom_nova_poshta_checkout_fields( $fields ) {
	global $woocommerce;
    $countries_obj   = new WC_Countries();
    $countries   = $countries_obj->__get('countries');
 	$kraina=array(
	    	'blank'		=> __( 'Select a day part', 'nova-poshta' ),
	        'morning'	=> __( 'In the morning', 'nova-poshta' ),
	        'afternoon'	=> __( 'In the afternoon', 'nova-poshta' ),
	        'evening' 	=> __( 'In the evening', 'nova-poshta' )
	    );
	unset($fields['billing']['billing_first_name']);
     unset($fields['billing']['billing_last_name']);
     unset($fields['billing']['billing_company']);
     unset($fields['billing']['billing_address_1']);
     unset($fields['billing']['billing_address_2']);
     unset($fields['billing']['billing_city']);
     unset($fields['billing']['billing_postcode']);
     unset($fields['billing']['billing_country']);
     unset($fields['billing']['billing_email']);
     unset($fields['billing']['billing_phone']);
     unset($fields['billing']['billing_state']);
	
	
	$fields['billing']['billing_first_name']=array(
		'label'  => __('Імя', 'woocommerce'),
		'required' => true,
		'priority' =>  "10",
    	'clear' => false,
);
	
	$fields['billing']['billing_last_name']=array(
		'label'  => __('Прізвище', 'woocommerce'),
		'required' => true,
		'priority' =>  "11",
    	'clear' => false,
);
	
	$fields['billing']['billing_phone']=array(
		'type' => 'tel',
		'label'  => __('Phone', 'woocommerce'),
		'required' => true,
		'priority' =>  "12",
    	'clear' => false,
);
	
	
	$fields['billing']['billing_email']= array(
		'type'		=> 'email',
      	'label'     => __('Email address', 'woocommerce'),
      	'required'  => true,
	  	'priority' =>  "13",
     );
	
//	$fields['billing']['billing_country']['priority']=15;
	$fields['billing']['billing_country']=array(
		'type' => 'select',
		'label'  => __('Country', 'woocommerce'),
		'required' => true,
		'priority' =>  "14",
    	'clear' => false,
		'options'       => $countries,
		
	
);
		
	$fields['billing']['billing_state']=array(
		'label'  => __('State / County', 'woocommerce'),
		'priority' =>  "15",
		'class' =>array("select ")
		);
	
	
		
	$fields['billing']['billing_city']=array(
		'label'  => __('City', 'woocommerce'),
		'required' => true,
		'priority' =>  "16",
    	'clear' => false,

);

	
	$fields['billing']['billing_address_nova_poshta_vidilenya']=array(
		'label'  => __('Відділення', 'woocommerce'),
		//'required' => true,
		'priority' =>  "17",
    	'required'  => false,
    'class'     => array('validate-required'),
    'clear'     => true,
);
	$fields['billing']['billing_address_1']=array(
		'label'     => __('Street address', 'woocommerce') , 
    	'placeholder'   => __('House number and street name', 'woocommerce'),
				'required' => true,
		'priority' =>  "18",

     );
	
	$fields['billing']['billing_address_2']=array(
		'placeholder' => __('Apartment, suite, unit etc.', 'woocommerce'),
		'priority' =>  "19",
				'required' => true,						   
	);
	
	$fields['billing']['billing_postcode']=array(
		'label'     => __('Postcode / ZIP', 'woocommerce'),
		'priority' =>  "20",

	);

 $fields['shipping']['shipping_registr'] = array(
        'label'     => __('Зарегистрировать вас?', 'woocommerce'),
       	'required'  => false,
    '	class'     => array('form-row-wide'),
	 	'clear'     => true,
	 	'priority' =>  "21",
     );
	
	
$billing_order = array(
        'billing_first_name',
        'billing_last_name',
	    'billing_phone',
        'billing_email',
        'billing_country',
        'billing_state',
        'billing_city',
		'billing_nova_poshta_vidilenya',
        'billing_address_1',
        'billing_address_2',
        'billing_postcode',
	        'billing_company',

    );
    $count = 0;
    $priority = 10;
$str='<table>';
	$str.='<tr>';
	        $str .= '<th>'.'$field_name'.'</th>';
        $str .= '<th>'.'label'.'</th>';
        $str .= '<th>'.'type'.'</th>';
        $str .= '<th>'.'class'.'</th>';
        $str .= '<th>'.'priority'.'</th>';
        $str .= '<th>'.'required'.'</th>';
        $str .= '<th>'.'clear'.'</th>';
		$str.='</tr>';
    foreach($billing_order as $field_name){
		$str.='<tr>';
		$str .= '<td>'.$field_name.'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['label'].'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['type'].'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['class'].'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['priority'].'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['required'].'</td>';
        $str .= '<td>'.$fields['billing'][$field_name]['clear'].'</td>';
		$str.=' </tr>';
    }
	$str.='</table>';
     return $fields;
}
	add_filter( 'woocommerce_checkout_fields' , 'custom_nova_poshta_checkout_fields',10 );//Додавання полів на сторінці checkout

function noha_poshta_my_custom_checkout_field_display_admin_order_meta($order){
   // echo '<p><strong>'.__('Phone From Checkout Form').':</strong> ' . get_post_meta( $order->get_id(), '_shipping_phone', true ) . '</p>';
}
add_action( 'woocommerce_admin_order_data_after_shipping_address', 'noha_poshta_my_custom_checkout_field_display_admin_order_meta', 10, 1 );//Проміжний підсумок

function my_custom_checkout_field_display_admin_order_meta($order){
    echo '<p><strong>'.__('Доставка на відділення нової пошти','nova-poshta').':</strong> ' . get_post_meta( $order->get_id(), '_billing_address_nova_poshta_vidilenya', true ) . '</p>';
}
add_action( 'woocommerce_admin_order_data_after_shipping_address', 'my_custom_checkout_field_display_admin_order_meta', 10, 1 );
