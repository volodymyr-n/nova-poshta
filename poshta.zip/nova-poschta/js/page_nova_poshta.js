jQuery(document).ready(function ($) {
	var stat;
	var obl = 'Виберіть область...';
	var mist = 'Виберіть місто...';
	var vid = 'Виберіть віділення...';
	var jsonmist;
	var currency_coefficient=1;
	var daniobmi;
  
var error='cервер не відповів, спробуйте ще раз';
	var dani_admin='';
     $.ajax({ //отримує дані з адмінки
		url: "/wp-admin/admin-ajax.php",
		method: 'post',
		data: {
			action: 'novaposhta_admin_Data',
		},
		success: function (response) {
		dani_admin=JSON.parse(response.slice(0, -1));
		}
		 });
   
	$.ajax({
			type: "get",
			url: "https://api.privatbank.ua/p24api/pubinfo?json&exchange&coursid=3",
			//data: '{ "apiKey": "'+dani_admin['key_api']+'", "modelName": "Address", "calledMethod": "getAreas", "methodProperties": {} }',
			statuscode: {
				404: function () {
					alert(error);
				}
			},
			success: function (data) {
				console.log(data);
				if(dani_admin['currencies']!=="UAH"){
					if(dani_admin['currency']!=="auto"){
					if(dani_admin['currencies']==="EUR"){
						currency_coefficient=data[0]['sale'];
					   }
					else if(dani_admin['currencies']==="USD"){
						currency_coefficient=data[2]['sale'];
					   }
					else if(dani_admin['currencies']==="RUR"){
						currency_coefficient=data[1]['sale'];
					   }
				   }
					else{
						if(dani_admin['currencies']==="EUR"){
						currency_coefficient=dani_admin['currency_number_eur'];
					   }
					else if(dani_admin['currencies']==="USD"){
						currency_coefficient=dani_admin['currency_number_usd'];
					   }
					else if(dani_admin['currencies']==="RUR"){
						currency_coefficient=dani_admin['currency_number_rur'];
					   }
				   
					}
				}
				else{
				currency_coefficient=1;
				}		
			}
	});
	function novastate() {
		$.ajax({
			type: "post",
			url: "https://api.novaposhta.ua/v2.0/json/Address/getAreas",
			data: '{ "apiKey": "'+dani_admin['key_api']+'", "modelName": "Address", "calledMethod": "getAreas", "methodProperties": {} }',
			statuscode: {
				404: function () {
					alert(error);
				}
			},
			success: function (data) {
				if (!data['success']) {
					console.log("Помилка загруки областей");
				} else { 
					var i = 1;
					var option_stat = '<select name="billing_state" id="billing_state"><option value="none">'+obl+'</option>'; 
					while (data['data'][i]) {
						option_stat += '<option data="' + data['data'][i]['Ref'] + '" value="' + data['data'][i]['Description'] + '">' + data['data'][i]['Description'] + '</option>';
						i++;
					}
                     
					option_stat+='</select>';
						var Obj = document.getElementById('billing_state');
                     
					Obj.outerHTML=option_stat;
				}
			}
		});
	}
	function danimistajaxjson(){
		$.ajax({
			type: "post",
			url: "https://api.novaposhta.ua/v2.0/json/address/searchsettlements/",
			data: '{"modelName": "Address","calledMethod": "getCities","methodProperties": {"Ref": ""},"apiKey": "'+dani_admin['key_api']+'"}',
			statuscode: {
				404: function () {
					alert(error);
				}
			},
			success: function (data) {
				if (!data['success']) {
					console.log("Помилка загруки міст");
				} else {
					jsonmist=data;
					}
				}
		});
	}
	function novamist(shtat_key) {
	if(jsonmist){   
		starttime=new Date;
		var option_stat='<select name="billing_city" id="billing_city" placeholder=""><option value="none">' + mist + '</option>';
		var k=0;
		var des;
 	if(dani_admin['language_of_the_cities']==='ru'){
		des='DescriptionRu';
}
		else{
				des='Description';
		};
		while(jsonmist['data'][k]){
			if(jsonmist['data'][k]['Area']===shtat_key){
						option_stat += '<option value="' + jsonmist['data'][k][des] + '" data="' + jsonmist['data'][k]['Ref'] + '">' + jsonmist['data'][k][des] + '</option>';
				
			}
			k++;
			
			  }
		//console.log(des);
		//console.log(jsonmist['data'][1]);
		//if(jsonmist['data']===shtat_key);
		option_stat+='</select>';
//if(		$('#billing_city').selectWoo()){
//									$('#billing_city').selectWoo('destroy');}
		document.getElementById('billing_city').outerHTML=option_stat;
$('#billing_city_field').css("display", "block");
              
		console.log((new Date-starttime)+"ms");
//		$('#billing_city').selectWoo();

}
	}
		function danividilenyaajaxjson(keya){
			var option_stat='<select name="billing_address_nova_poshta_vidilenya" id="billing_address_nova_poshta_vidilenya" placeholder=""><option value="none">' + vid + '</option>';
					var des;
 	if(dani_admin['language_of_the_cities']==='ru'){
	des='DescriptionRu';
}
		else{
				des='Description';
		};
			
			
		$.ajax({
			type: "post",
			url: "https://api.novaposhta.ua/v2.0/json/address/searchsettlements/",
			data: '{ "modelName": "AddressGeneral", "calledMethod": "getWarehouses", "methodProperties": { "CityRef": "'+keya+'", "Language": "ua" }, "apiKey": "'+dani_admin['key_api']+'" }',
			statuscode: {
				404: function () {
					alert(error);
				}
			},
			success: function (data) {
				if (!data['success']) {
					console.log("Помилка загруки віділень");
				} else {
						var i=0;
					while(data['data'][i]){
					option_stat += '<option value="'+$("#billing_state option:selected").text()+' обл. м. '+ data['data'][i]['CityDescription']+' '+data['data'][i]['Description']+'">' + data['data'][i][des] + '</option>';
					i++;
					}
//					if($('#billing_address_nova_poshta_vidilenya').selectWoo()){
//											$('#billing_address_nova_poshta_vidilenya').selectWoo('destroy');
//				}
					 
					option_stat += "</select>";
					document.getElementById('billing_address_nova_poshta_vidilenya').outerHTML=option_stat;
                  
                $('#billing_address_nova_poshta_vidilenya_field').css("display", "block");
					//	$('#billing_address_nova_poshta_vidilenya').html(option_stat);
//					$('#billing_address_nova_poshta_vidilenya').selectWoo();
		
				}
			}
		});
	}
	
	//Вводить в систему вартість доставки
	function onlineCalculatorUpDataSystem(num){
		$.ajax({ //перезавантажує вартість доставки
		url: "/wp-admin/admin-ajax.php",
		method: 'post',
		data: {
			action: 'novaposhta_shipingonline',
			vidilenya: num
		},
		success: function (response) {
//            $('.woocommerce-Price-amount').html('<span class="woocommerce-Price-amount amount">'+num+'&nbsp;<span class="woocommerce-Price-currencySymbol">грн.</span></span>'')';
//            $('.woocommerce-Price-amount').html(num+'&nbsp;'); 
			
			console.log("Обновило");
			console.log("Ціна:"+num); 
            var k=$('#shipping_method_0_nova_poshta').parent('div').children('label').children('.woocommerce-Price-amount');   
    var i=k.html();

    i=i.split('&');
    $('#shipping_method_0_nova_poshta').parent('div').children('label').children('.woocommerce-Price-amount').html(num+'&'+i[1]); 
            var sum=$('tr.cart-subtotal').children('td').children('span').html();
            sum=sum.split('&'); 
            
            var ps=$('.order-total').children('td').children('strong').children('span');
            var zin=parseInt(sum[0])+parseInt(num);
            zin+='&'+i[1];   
            var yu=ps.html(zin);
            
//            $('#shipping_method_0_nova_poshta').html('55');    
            
               
            $('body').trigger('update_checkout'); 
//            $('span.woocommerce-Price-amount').after('&nbsp;<span class="woocommerce-Price-currencySymbol">грн.'); 

					   }
				
			});	
	
	}
	
	//розраховує вартість доставки на новій пошті
		function onlineCalculator(key_city){
			//"ServiceType": "",
			if(dani_admin['address_of_the_sender_the_parcel_paid']!="Seller"){//доставку оплачує продавець
			
	$.ajax({
		type: "post",
			url: "https://api.novaposhta.ua/v2.0/json/",
		data: '{"modelName": "InternetDocument", "calledMethod": "getDocumentPrice", "methodProperties": { "CitySender": "06f878ec-4079-11de-b509-001d92f78698", "CityRecipient": "'+key_city+'", "Weight": "'+dani_admin['default_weight']+'", "ServiceType": "'+dani_admin['address_of_the_sender_the_parcel']+'Warehouse", "Cost": "400", "CargoType": "Cargo", "SeatsAmount": "1", "RedeliveryCalculate": { "CargoType": "Money", "Amount": "400"}},"apiKey": "'+dani_admin['key_api']+'"}',
success: function (response) {
    
 
	var num=response['data'][0]['Cost'];
	
			onlineCalculatorUpDataSystem(num/currency_coefficient);
					   }
	});
			}
			else{
			onlineCalculatorUpDataSystem('free');	
			}
			
	
		}
	var timerout=100;
	var elem=false;
	

					var elem1=0;
	function tecur1(){
		
	setTimeout(function () {  // Задержка 2 секунды, для примера.
if(dani_admin===''){
	console.log("1");
	tecur1();
}
		else{
		console.log("2");
			timerout=2000;
							

			$("#billing_country").change(function () {
						
				if ($("#billing_country").val() === "UA" ||  !$("#billing_country")) {
					if(!jsonmist){
					novastate();
					danimistajaxjson();
					}
					if(elem1===0){
					setTimeout(function () { 
			var Obj = document.getElementById('billing_state');
						elem1=Obj.outerHTML;

					},1000);
					}
					else{
						var Obj = document.getElementById('billing_state');
						Obj.outerHTML=elem1;	
					}
					
						setTimeout(function (){
//					$('#billing_state').select2();
											  },1000);
					timeoutTecur2();
					if(elem){
						elem=false;
					}
				} 
				else {
					//очищення
//					if($('#billing_state').select2()){
//					$('#billing_state').select2('destroy');}
//						if($('#billing_address_nova_poshta_vidilenya').selectWoo()){
//											$('#billing_address_nova_poshta_vidilenya').selectWoo('destroy');}
//					if(	$('#billing_city').selectWoo()){
//									$('#billing_city').selectWoo('destroy');}
					//console.log(document.getElementById('billing_address_nova_poshta_vidilenya_field').outerHTML+'-----');	
$('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
				document.getElementById('billing_address_nova_poshta_vidilenya').outerHTML='<input type="text" class="input-text " name="billing_address_nova_poshta_vidilenya" id="billing_address_nova_poshta_vidilenya" placeholder="">';
					var Obj1 = document.getElementById('billing_state'); //any element to be fully replaced
					elem=true;
					Obj1.outerHTML='<input type="text" class="input-text " value="" placeholder="" name="billing_state" id="billing_state">';
//					 document.getElementById('select2-billing_state-container').outerHTML='';
					 document.getElementById('billing_city').outerHTML='<input type="text" class="input-text " name="billing_city" id="billing_city" placeholder="">';
					$('#billing_state').html('<option value="none">' + vid + '</option>');
			}});
		}
					}, 2000);}
	function timeoutTecur2(){
		setTimeout(function (){

		if($('#billing_state').val()!==''){
			tecur2();
		}
			else {
				timeoutTecur2();
			}
		},500);
}
function tecur2(){
			
	$("#billing_state").change(function () {
			$("#billing_state option:selected").each(function () {
				if ($("#billing_state").val() !== "none") {
					//console.log($("#billing_state").val());
					novamist($("#billing_state option:selected").attr('data'));
$('#billing_city').css("display", "block");
					tecur3();
					
				} else {
					//очищення
					//$('#billing_state').html('<option value="none">' + obl + '</option>');
					$('#billing_city').html('<option value="none">' + mist + '</option>');
					$('#billing_address_nova_poshta_vidilenya').html('<option value="none">' + vid + '</option>');
                    $('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
				}

			}); 
		}) 
		.trigger("change");
		}
function tecur3(){

	$("#billing_city").change(function () {
			$("#billing_city option:selected").each(function () {
				if ($("#billing_city").val() !== "none") {
					danividilenyaajaxjson($("#billing_city option:selected").attr('data'));
					if(dani_admin['calculete_shipping']){
					onlineCalculator($("#billing_city option:selected").attr('data'));
						

				}
				} else {
					//очищення
					$('#billing_address_nova_poshta_vidilenya').html('<option value="none">' + vid + '</option>');
                    $('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
				}

			}); 
		})
		.trigger("change");
		}
	tecur1();
//	$("#billing_country").select2();
    function start(){
    
//        if ($("#billing_country").val() === "UA" && $("#shipping_method_0_nova_poshta:checked").length>0) {
        if ($("#shipping_method_0_nova_poshta:checked").length>0) {
					if(!jsonmist){
					novastate();
					danimistajaxjson();
					}
					if(elem1===0){
					setTimeout(function () { 
			var Obj = document.getElementById('billing_state');
						elem1=Obj.outerHTML;
                $('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
                $('#billing_city_field').css("display", "none");
               $('#billing_address_1_field').css("display", "none");
					},1000);
					}
					else{ 
						var Obj = document.getElementById('billing_state');
						Obj.outerHTML=elem1;	
                        $('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
                $('#billing_city_field').css("display", "none");
               $('#billing_address_1_field').css("display", "none");
                       
					} 
					
//						setTimeout(function (){$('#billing_state').select2();},1000);
					timeoutTecur2();
					if(elem){
						elem=false;
					}
                 $('#billing_address_nova_poshta_vidilenya_field').css("display", "none");
            
				}
        else{  
            console.log("2");
//            $('#billing_state').html('<input type="text" class="input-text " name="billing_state" id="billing_state" placeholder="" value="" data-placeholder="">');
         
            document.getElementById('billing_state').outerHTML='<input type="text" class="input-text " name="billing_state" id="billing_state" placeholder="" value="" data-placeholder="">';
            document.getElementById('billing_city').outerHTML='<input type="text" class="input-text " name="billing_city" id="billing_city" placeholder="" value="" data-placeholder="">';

//            $('#billing_state').html('<input type="text" class="input-text " name="billing_state" id="billing_state" placeholder="" value="" data-placeholder="">');
//            $('#billing_city').html('<input type="text" class="input-text " name="billing_city" id="billing_city" placeholder="" value="" data-placeholder="">');
               
               $('#billing_city_field').css("display", "block");
               $('#billing_address_1_field').css("display", "block");
            $('#billing_address_nova_poshta_vidilenya_field').css("display", "none"); 
               

        }
    }
	function tecuronce(){
		if(dani_admin===''){
		   setTimeout(function (){
		tecuronce();
	},300);
		   }
	else{
        start();
		
		   }
}
    $('#shipping_method').click(function(){
        start();
    });
					   tecuronce();   
      
//      $('#shipping_method_0_nova_poshta').parent('label').css('display', 'block').html('55');     
	});
